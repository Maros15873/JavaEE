module jsonJavaEE {
	requires java.json;
}